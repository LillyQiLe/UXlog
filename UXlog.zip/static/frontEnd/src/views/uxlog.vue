<template>
  <div>
      这里是uxlog页面
  </div>
</template>

<script>
export default {
  data () {
    return {
      msg: 'hello'
    }
  }
}
</script>

<style>
</style>
